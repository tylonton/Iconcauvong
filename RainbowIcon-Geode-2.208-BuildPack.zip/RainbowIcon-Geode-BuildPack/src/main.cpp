#include <Geode/Geode.hpp>
#include <Geode/modify/PlayerObject.hpp>
#include <cmath>

using namespace geode::prelude;

namespace {
    ccColor3B hsvToRgb(float h, float s, float v) {
        h = std::fmod(h, 360.f);
        if (h < 0.f) h += 360.f;

        float c = v * s;
        float x = c * (1.f - std::fabs(std::fmod(h / 60.f, 2.f) - 1.f));
        float m = v - c;

        float r = 0.f, g = 0.f, b = 0.f;
        if (h < 60.f)       r = c, g = x;
        else if (h < 120.f) r = x, g = c;
        else if (h < 180.f) g = c, b = x;
        else if (h < 240.f) g = x, b = c;
        else if (h < 300.f) r = x, b = c;
        else                r = c, b = x;

        return ccc3(
            static_cast<GLubyte>((r + m) * 255.f),
            static_cast<GLubyte>((g + m) * 255.f),
            static_cast<GLubyte>((b + m) * 255.f)
        );
    }
}

class $modify(RainbowPlayerObject, PlayerObject) {
    bool m_rainbowInitialized = false;
    ccColor3B m_originalColor = ccc3(255, 255, 255);
    float m_rainbowHue = 0.f;

    void update(float dt) {
        PlayerObject::update(dt);

        if (!m_rainbowInitialized) {
            m_originalColor = this->getColor();
            m_rainbowInitialized = true;
        }

        auto mod = Mod::get();
        bool enabled = mod->getSettingValue<bool>("enabled");
        float speed = mod->getSettingValue<float>("speed");

        if (!enabled) {
            this->setColor(m_originalColor);
            return;
        }

        // speed = 1.0 means one complete rainbow cycle in about 2 seconds.
        m_rainbowHue += dt * 180.f * speed;
        if (m_rainbowHue >= 360.f)
            m_rainbowHue = std::fmod(m_rainbowHue, 360.f);

        this->setColor(hsvToRgb(m_rainbowHue, 1.f, 1.f));
    }
};
