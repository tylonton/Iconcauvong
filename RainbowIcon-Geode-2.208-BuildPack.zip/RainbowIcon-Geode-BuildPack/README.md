# Rainbow Icon — One-click Geode build

This package builds the Rainbow Icon mod for **Geometry Dash 2.208 / Android64** using GitHub Actions.

## What you get

- Rainbow icon effect
- In-game settings:
  - Rainbow Icon: ON/OFF
  - Rainbow Speed: 0.1x–5.0x
- Automatic `.geode` build artifact

## Build without installing CMake/Geode SDK

1. Create a GitHub repository and upload **all files in this folder**.
2. Open the repository's **Actions** tab.
3. Select **Build Rainbow Icon**.
4. Press **Run workflow**.
5. Wait for the build to finish.
6. Open the completed workflow run.
7. In **Artifacts**, download `RainbowIcon-Android64`.
8. Inside the downloaded ZIP is the `.geode` file.

### For Samsung A05

Use the **Android64** artifact. After downloading the `.geode`, install it through Geode Launcher in the normal way.

## Important

The GitHub workflow uses the official `geode-sdk/build-geode-mod` GitHub Action. It handles the Geode SDK/CLI setup and produces the `.geode` package automatically.

The workflow is configured with `workflow_dispatch`, so GitHub shows a **Run workflow** button. It also builds automatically when you push to the `main` branch.
